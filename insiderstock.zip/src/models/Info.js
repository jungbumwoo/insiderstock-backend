import mongoose from "mongoose";

const infoSchema = new mongoose.Schema({
    ticker: String,
    company: String,
    insiderName: String,
    insiderPosition: String,
    date: { type: Date },
    transaction: String,
    insiderTradingShares: String,
    sharesChange: String,
    purchasePrice: String,
    cost: String,
    finalShare: String,
    // price change since insider trade
    priceChangeSIT: { type: String },
    // DividendYield: String,
    PERatio: String,
    MarketCap: String,
    createdAt: { type: Date, default: Date.now }
});

const model = mongoose.model('Info', infoSchema);

export default model;